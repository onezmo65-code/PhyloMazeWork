# YOUWARE.md

# Nebula Maze: Fog of War (v1.4.0)

A React-based dungeon crawler game with fog of war mechanics, inventory system, and AI-generated content.

## Project Overview

- **Project Type**: React + TypeScript Game
- **Entry Point**: `src/main.tsx` -> `src/App.tsx` -> `src/components/MazeGame.tsx`
- **Build System**: Vite
- **Styling**: Tailwind CSS
- **Version**: 1.4.0

## Key Features

- **Procedural Generation**: Randomly generated mazes with varying difficulty levels and shapes.
  - **Shapes**: Supports Rectangle, Circle, Diamond, and Pineapple shapes.
  - **Level Progression**: Grid size increases with levels (10x10 to 25x25).
  - **Themes**: Dungeon, Orchard, Farm, Vacation.
  - **Smart Exit Placement**: Exit is strictly placed on the **edge** of the maze (boundary of the valid shape), prioritizing locations at least 66% of the maximum path distance from the start.
  - **Variable Start Position**: Player start is chosen randomly from valid carved cells (not always center), ensuring variety while maintaining reachability.
  - **Item Spacing**: Items and hazards are placed with a minimum Manhattan distance of 3 squares from each other to prevent clustering.
- **Fog of War**: Visibility system that reveals the map as the player explores.
  - **Prize Hiding**: Items are completely hidden in the fog until the player is within visibility range.
  - **Exit Lock**: The exit is hidden/locked until 90% of the maze is explored.
  - **Explored Visibility**: Explored but currently unseen areas show walls faintly (30% opacity) to aid backtracking.
- **Inventory System**: Expanded inventory with 30+ items (Water, Rope, Shield, etc.) to mitigate various hazards.
  - **Starter Items**: Players receive 3 unique random items at the start of *every* level.
- **Hazard System**:
  - **Data-Driven Encounters**: Hazards and remedies are defined in `src/data/encounters.json`.
  - **Interactive Mitigation**: Hazards (Fire, Snake, Robber, Aliens, etc.) trigger an inventory selection prompt.
  - **Persistent UI**: Hazard icon and name are clearly displayed in the side panel during the encounter.
  - **Specific Hazards**: Hazards are now specific types (Snake, Quicksand, Bees, etc.) with matching icons and names.
  - **Complex Logic**: Supports priority rules (e.g., lowest loss applies) and item consumption.
  - **Consequences**: Failure results in HP loss and potential item loss.
  - **Failure Messages**: Randomly selected encouraging phrases (e.g., "Better luck next time", "Knowledge is power") instead of just "Failure".
- **Academic Encounters**:
  - **Repository**: Questions are loaded from `public/questions.json` AND `src/data/academicQuestions.json`.
  - **Trigger**: 5% chance to trigger an academic challenge when moving to an empty cell.
  - **Scoring**: Correct (+10/20/40 based on difficulty), Wrong (-10), Skip (-5).
  - **UI**: Supports Multiple Choice, Boolean, Text Input, and **Image Prompts**.
  - **Variety**: Questions are selected uniformly from the entire pool without category bias.
  - **Operator Mode**: In-game admin panel to view, edit, **import**, and download the question repository.
- **Controls**:
  - **Keyboard**: Arrow keys for movement.
  - **On-Screen**: Directional buttons available under the maze grid for touch/mouse users.
  - **Input Locking**: Movement controls (both keyboard and on-screen) are locked when a modal (question/hazard) is open.
- **Dynamic Difficulty**:
  - **Modes**: Easy, Hard, Tough Genius.
  - **Scaling**: Difficulty affects hazard density, item scarcity, and academic question points.
  - **Persistence**: Difficulty is now tracked in High Scores.
- **Monetization**:
  - **Free Trial**: First 2 runs are free.
  - **Paywall**: 3rd run triggers a paywall (Watch Ads or Subscription).
  - **Signup**: Encourages account creation to save progress.
- **Leaderboard**: Local storage persistence for high scores, now displaying difficulty mode.
- **Audio System**: Synthesized sound effects (step, bump, pickup, hazard, correct, wrong, etc.).
- **Responsive Design**: Split-screen layout (Maze Left, Dashboard Right).

## Architecture

### Components

- **MazeGame.tsx**: Main game container. Manages layout (Split Screen), game loop, state, and rendering.
- **PlayerAvatar.tsx**: SVG component for the player character (Human adventurer) with `bounce-player` animation.
- **OperatorPanel.tsx**: Admin interface for managing `questions.json`.
- **Leaderboard.tsx**: High score display with difficulty indicators.
- **Paywall.tsx**: Monetization overlay.
- **SignupPrompt.tsx**: User registration overlay.

### Utils

- **mazeUtils.ts**: Maze generation and logic. Includes BFS for exit placement, difficulty scaling, and safe item placement.
- **questionUtils.ts**: Question loading and validation registry.
- **leaderboardUtils.ts**: Score persistence (localStorage) with robust error handling.

### State Management

- **GameState**: Managed in `MazeGame.tsx` (grid, player, score, bag, level, difficulty).
- **Encounter State**: `modal` state handles questions and inventory selection, rendered in the Sidebar.
- **User State**: `localStorage` tracks `runCount`, `isPremium`, `userEmail` (nickname), and `highscores`.

## Development

### Commands

- **Install**: `npm install`
- **Dev**: `npm run dev`
- **Build**: `npm run build`
- **Preview**: `npm run preview`

### Environment Variables

- `VITE_API_KEY`: Google Gemini API Key (optional for AI features).
