import React, { useState } from 'react';
import { Play, CreditCard, Star, X } from 'lucide-react';

interface PaywallProps {
  onUnlock: (method: 'ad' | 'sub_monthly' | 'sub_yearly') => void;
  onClose: () => void; // To cancel/exit
}

export const Paywall: React.FC<PaywallProps> = ({ onUnlock, onClose }) => {
  const [adCount, setAdCount] = useState(0);

  const handleWatchAd = () => {
    // Mock Ad Logic
    if (adCount === 0) {
      alert("Watching Ad 1/2... (Imagine a video here)");
      setAdCount(1);
    } else {
      alert("Watching Ad 2/2... Done!");
      onUnlock('ad');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-500 hover:text-white">
          <X className="w-6 h-6" />
        </button>

        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-yellow-500/20 text-yellow-500 mb-4">
            <Star className="w-8 h-8 fill-current" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Continue Your Adventure</h2>
          <p className="text-slate-400">You've enjoyed your free runs! Choose an option to keep playing.</p>
        </div>

        <div className="space-y-4">
          {/* Ad Option */}
          <button 
            onClick={handleWatchAd}
            className="w-full p-4 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-xl flex items-center justify-between group transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg group-hover:scale-110 transition-transform">
                <Play className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="font-bold text-white">Watch Ads</div>
                <div className="text-xs text-slate-400">Watch 2 short videos to play</div>
              </div>
            </div>
            <div className="text-sm font-mono text-blue-400">
              {adCount}/2
            </div>
          </button>

          {/* Monthly */}
          <button 
            onClick={() => onUnlock('sub_monthly')}
            className="w-full p-4 bg-gradient-to-r from-cyan-900 to-slate-800 hover:from-cyan-800 hover:to-slate-700 border border-cyan-500/30 rounded-xl flex items-center justify-between group transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-cyan-500/20 text-cyan-400 rounded-lg group-hover:scale-110 transition-transform">
                <CreditCard className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="font-bold text-white">Monthly Pass</div>
                <div className="text-xs text-slate-400">Remove ads & save progress</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-bold text-white">$1.99</div>
              <div className="text-xs text-slate-400">/month</div>
            </div>
          </button>

          {/* Yearly */}
          <button 
            onClick={() => onUnlock('sub_yearly')}
            className="w-full p-4 bg-gradient-to-r from-yellow-900 to-slate-800 hover:from-yellow-800 hover:to-slate-700 border border-yellow-500/30 rounded-xl flex items-center justify-between group transition-all relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 bg-yellow-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-bl-lg">
              BEST VALUE
            </div>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-yellow-500/20 text-yellow-400 rounded-lg group-hover:scale-110 transition-transform">
                <Star className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="font-bold text-white">Yearly Pro</div>
                <div className="text-xs text-slate-400">All features, best price</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-bold text-white">$15.99</div>
              <div className="text-xs text-slate-400">/year</div>
            </div>
          </button>
        </div>

        <p className="text-center text-xs text-slate-500 mt-6">
          By continuing, you agree to our Terms of Service and Privacy Policy.
        </p>
      </div>
    </div>
  );
};
