import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  Map as MapIcon, Shield, RefreshCw, Sparkles, AlertTriangle, Skull, Flame, CloudFog, Snowflake, HelpCircle, Settings, Trophy, Menu, X, Backpack, CheckSquare, Play, User
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { 
  generateMaze, LEVEL_CONFIG, ItemType, Direction, Cell, ItemTypeValues, Theme 
} from '../utils/mazeUtils';
import { getRandomQuestion, checkAnswer, Question, registry } from '../utils/questionUtils';
import { Leaderboard } from './Leaderboard';
import { getHighScores, saveHighScore, isHighScore } from '../utils/leaderboardUtils';
import { PlayerAvatar, AvatarType } from './PlayerAvatar';
import { OperatorPanel } from './OperatorPanel';
import { Paywall } from './Paywall';
import { SignupPrompt } from './SignupPrompt';
import encounters from '../data/encounters.json';
import academicQuestions from '../data/academicQuestions.json';

// --- CONSTANTS ---
const VISIBILITY_RADIUS = 1;

const ITEMS_CONFIG = {
  [ItemType.Health]: { char: '💊', color: 'text-red-500', name: 'Health Pack' },
  [ItemType.Score]: { char: '💎', color: 'text-cyan-400', name: 'Gem' },
  [ItemType.Hazard]: { char: '🐍', color: 'text-green-600', name: 'Hazard' },
  [ItemType.Weapon]: { char: '🗡️', color: 'text-slate-300', name: 'Dagger' },
  [ItemType.Exit]: { char: '🚪', color: 'text-yellow-500', name: 'Exit' },
  [ItemType.Start]: { char: 'S', color: 'text-white', name: 'Start' },
  [ItemType.Empty]: { char: '', color: '', name: '' },
  [ItemType.Fire]: { char: '🔥', color: 'text-orange-500', name: 'Bushfire' },
  [ItemType.Fumes]: { char: '💨', color: 'text-purple-500', name: 'Toxic Fumes' },
  [ItemType.IceCube]: { char: '🧊', color: 'text-blue-300', name: 'Ice Cube' },
  [ItemType.CO2]: { char: '☁️', color: 'text-gray-400', name: 'CO2 Canister' },
  [ItemType.Antivenom]: { char: '💉', color: 'text-emerald-400', name: 'Antivenom' },
  [ItemType.Robber]: { char: '🦹', color: 'text-purple-600', name: 'Robber' },
  // Specific Hazards
  [ItemType.Snake]: { char: '🐍', color: 'text-green-500', name: 'Snake' },
  [ItemType.Quicksand]: { char: '🏜️', color: 'text-yellow-700', name: 'Quicksand' },
  [ItemType.Bees]: { char: '🐝', color: 'text-yellow-400', name: 'Swarm of Bees' },
  [ItemType.Meteor]: { char: '☄️', color: 'text-orange-600', name: 'Meteor Storm' },
  [ItemType.Aliens]: { char: '👽', color: 'text-green-400', name: 'Violent Alien' },
  [ItemType.Bear]: { char: '🐻', color: 'text-amber-800', name: 'Bear' },
  // New Items
  [ItemType.Water]: { char: '💧', color: 'text-blue-400', name: 'Water' },
  [ItemType.Bandage]: { char: '🩹', color: 'text-white', name: 'Bandage' },
  [ItemType.Herb]: { char: '🌿', color: 'text-green-400', name: 'Herb' },
  [ItemType.Honey]: { char: '🍯', color: 'text-yellow-400', name: 'Honey' },
  [ItemType.Rope]: { char: '🧶', color: 'text-orange-300', name: 'Rope' },
  [ItemType.Stick]: { char: '🪵', color: 'text-orange-800', name: 'Stick' },
  [ItemType.Teamwork]: { char: '🤝', color: 'text-pink-400', name: 'Teamwork' },
  [ItemType.ShieldGenerator]: { char: '🛡️', color: 'text-cyan-300', name: 'Shield Generator' },
  [ItemType.EvasiveManeuver]: { char: '💨', color: 'text-white', name: 'Evasive Maneuver' },
  [ItemType.NegotiationItem]: { char: '📜', color: 'text-yellow-200', name: 'Treaty' },
  [ItemType.RadiationShield]: { char: '☢️', color: 'text-green-300', name: 'Rad Shield' },
  [ItemType.OxygenTank]: { char: '🤿', color: 'text-blue-500', name: 'Oxygen Tank' },
  [ItemType.OxygenMask]: { char: '😷', color: 'text-white', name: 'Oxygen Mask' },
  [ItemType.Root]: { char: '🥕', color: 'text-orange-600', name: 'Root' },
  [ItemType.Trap]: { char: '🪤', color: 'text-slate-400', name: 'Trap' },
  [ItemType.Shelter]: { char: '⛺', color: 'text-green-700', name: 'Shelter' },
  [ItemType.PharmacyPack]: { char: '🎒', color: 'text-red-400', name: 'Pharmacy Pack' },
  [ItemType.Sunscreen]: { char: '🧴', color: 'text-yellow-100', name: 'Sunscreen' },
  [ItemType.LifeJacket]: { char: '🦺', color: 'text-orange-500', name: 'Life Jacket' },
  [ItemType.Ventilation]: { char: '🌬️', color: 'text-blue-200', name: 'Ventilation' },
  [ItemType.Helmet]: { char: '⛑️', color: 'text-red-600', name: 'Helmet' },
  [ItemType.Shield]: { char: '🛡️', color: 'text-slate-300', name: 'Shield' },
  [ItemType.Money]: { char: '💰', color: 'text-yellow-400', name: 'Money' },
  [ItemType.ReflexBoost]: { char: '⚡', color: 'text-yellow-300', name: 'Reflex Boost' },
  [ItemType.Dodge]: { char: '🏃', color: 'text-white', name: 'Dodge' },
  [ItemType.HealthBerries]: { char: '🍒', color: 'text-red-500', name: 'Health Berries' },
  [ItemType.FlowerPollen]: { char: '🌻', color: 'text-yellow-300', name: 'Flower Pollen' },
  [ItemType.GameMeat]: { char: '🍖', color: 'text-orange-700', name: 'Game Meat' },
  [ItemType.Syringe]: { char: '💉', color: 'text-slate-200', name: 'Syringe' },
  [ItemType.PoisonBerries]: { char: '🫐', color: 'text-purple-800', name: 'Poison Berries' },
};

const THEME_COLORS: Record<Theme, string> = {
  dungeon: 'bg-slate-900',
  orchard: 'bg-emerald-900',
  farm: 'bg-amber-900',
  vacation: 'bg-sky-900',
};

// --- AUDIO SERVICE ---
let audioCtx: AudioContext | null = null;

const getAudioContext = () => {
  if (!audioCtx) {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContext) {
      audioCtx = new AudioContext();
    }
  }
  return audioCtx;
};

const playSound = (type: 'step' | 'bump' | 'pickup' | 'hazard' | 'levelUp' | 'die' | 'correct' | 'wrong') => {
  const ctx = getAudioContext();
  if (!ctx) return;

  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.connect(gain);
  gain.connect(ctx.destination);

  const now = ctx.currentTime;

  switch (type) {
    case 'step':
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(100, now);
      osc.frequency.exponentialRampToValueAtTime(50, now + 0.05);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      osc.start(now);
      osc.stop(now + 0.05);
      break;
    case 'bump':
      osc.type = 'square';
      osc.frequency.setValueAtTime(100, now);
      osc.frequency.linearRampToValueAtTime(80, now + 0.1);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      osc.start(now);
      osc.stop(now + 0.1);
      break;
    case 'pickup':
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.1);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
      break;
    case 'hazard':
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(100, now);
      osc.frequency.linearRampToValueAtTime(50, now + 0.3);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
      break;
    case 'levelUp':
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, now);
      osc.frequency.setValueAtTime(600, now + 0.1);
      osc.frequency.setValueAtTime(800, now + 0.2);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.linearRampToValueAtTime(0, now + 0.5);
      osc.start(now);
      osc.stop(now + 0.5);
      break;
    case 'die':
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, now);
      osc.frequency.exponentialRampToValueAtTime(10, now + 1);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.linearRampToValueAtTime(0, now + 1);
      osc.start(now);
      osc.stop(now + 1);
      break;
    case 'correct':
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.1);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
      break;
    case 'wrong':
      osc.type = 'square';
      osc.frequency.setValueAtTime(150, now);
      osc.frequency.linearRampToValueAtTime(100, now + 0.2);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
      break;
  }
};

// --- LAUNCHER COMPONENT ---
const Launcher = ({ 
  onStart, 
  difficulty, 
  setDifficulty, 
  playerIcon, 
  setPlayerIcon 
}: { 
  onStart: () => void, 
  difficulty: 'easy' | 'hard' | 'tough_genius', 
  setDifficulty: (d: 'easy' | 'hard' | 'tough_genius') => void,
  playerIcon: AvatarType,
  setPlayerIcon: (i: AvatarType) => void
}) => {
  return (
    <div className="absolute inset-0 bg-slate-900 z-40 flex flex-col items-center justify-center p-6 animate-in fade-in">
      <div className="max-w-md w-full space-y-8 text-center">
        <div>
          <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-2">
            NEBULA MAZE
          </h1>
          <p className="text-slate-400">Fog of War • Survival • Trivia</p>
        </div>

        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700 space-y-6">
          {/* Difficulty Selector */}
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-2">
              {(['easy', 'hard', 'tough_genius'] as const).map((d) => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`py-2 px-1 rounded-lg text-sm font-bold capitalize transition-all
                    ${difficulty === d 
                      ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-900/20' 
                      : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}
                >
                  {d.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Icon Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Explorer Icon</label>
            <div className="flex justify-center gap-4">
              {(['boy', 'girl', 'cat', 'dog', 'car'] as const).map((icon) => (
                <button
                  key={icon}
                  onClick={() => setPlayerIcon(icon)}
                  className={`p-2 rounded-xl transition-all border-2 
                    ${playerIcon === icon 
                      ? 'border-cyan-500 bg-cyan-500/10 scale-110' 
                      : 'border-transparent hover:bg-slate-700'}`}
                >
                  <PlayerAvatar type={icon} className="w-10 h-10" />
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={onStart}
            className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl font-black text-lg shadow-xl shadow-cyan-900/20 transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2"
          >
            <Play className="w-6 h-6 fill-current" />
            START ADVENTURE
          </button>
        </div>
      </div>
    </div>
  );
};

export const MazeGame: React.FC = () => {
  // --- STATE ---
  const [grid, setGrid] = useState<Cell[][]>([]);
  const [playerPos, setPlayerPos] = useState({ x: 0, y: 0 });
  const [hp, setHp] = useState(100);
  const [score, setScore] = useState(0);
  const [bag, setBag] = useState<ItemTypeValues[]>([]);
  const [messageLog, setMessageLog] = useState<string[]>(['Welcome to the Nebula Maze!']);
  const [level, setLevel] = useState(1);
  const [theme, setTheme] = useState<Theme>('dungeon');
  const [modal, setModal] = useState<{
    isOpen: boolean;
    type: 'alert' | 'question' | 'gameOver' | 'levelComplete' | 'inventory';
    title: string;
    message?: string;
    question?: Question;
    hazardType?: string;
    onConfirm?: (answer?: any) => void;
  }>({ isOpen: false, type: 'alert', title: '' });
  
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showOperator, setShowOperator] = useState(false);
  const [scoreHistory, setScoreHistory] = useState<{ level: number, score: number }[]>([]);
  const [playerName, setPlayerName] = useState('');
  const [isNewHighScore, setIsNewHighScore] = useState(false);
  const [encounteredHazards, setEncounteredHazards] = useState<string[]>([]);

  // Monetization & Settings State
  const [runCount, setRunCount] = useState(0);
  const [isPremium, setIsPremium] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null); // Stores Nickname now
  const [showPaywall, setShowPaywall] = useState(false);
  const [adWatched, setAdWatched] = useState(false);
  const [showSignup, setShowSignup] = useState(false);
  const [difficulty, setDifficulty] = useState<'easy' | 'hard' | 'tough_genius'>('easy');
  const [playerIcon, setPlayerIcon] = useState<AvatarType>('boy');
  const [textAnswer, setTextAnswer] = useState('');

  const containerRef = useRef<HTMLDivElement>(null);

  // --- INIT ---
  useEffect(() => {
    const init = async () => {
      await registry.load();
      // Add academic questions to registry
      academicQuestions.forEach(q => registry.add(q as Question));
    };
    init();

    const savedRunCount = localStorage.getItem('runCount');
    const savedPremium = localStorage.getItem('isPremium');
    const savedEmail = localStorage.getItem('userEmail');
    if (savedRunCount) setRunCount(parseInt(savedRunCount));
    if (savedPremium === 'true') setIsPremium(true);
    if (savedEmail) setUserEmail(savedEmail);
  }, []);

  const checkAndStartLevel = (lvl: number, currentRunCount: number, premium: boolean, ad: boolean) => {
    // Paywall Logic: Free for first 2 runs, then requires Premium or Ad
    if (!premium && !ad && currentRunCount >= 2 && lvl === 1) {
      setShowPaywall(true);
      return;
    }
    startLevel(lvl);
  };

  const handleLauncherStart = () => {
    if (runCount >= 2 && !isPremium && !adWatched) {
      setShowPaywall(true);
    } else {
      setRunCount(c => {
        const newCount = c + 1;
        localStorage.setItem('runCount', newCount.toString());
        return newCount;
      });
      startLevel(1);
      setShowLauncher(false);
    }
  };

  const handlePaywallUnlock = (method: 'ad' | 'sub') => {
    if (method === 'sub') {
      setIsPremium(true);
      localStorage.setItem('isPremium', 'true');
    } else {
      setAdWatched(true);
    }
    setShowPaywall(false);
    // Don't auto-start, let them click Start again or auto-start if they were blocked
    // Better UX: Auto start if they were clicking start
    // But for now, just close paywall and let them click start.
  };

  const handleSignup = (email: string) => {
    setUserEmail(email);
    localStorage.setItem('userEmail', email);
    setShowSignup(false);
    if (isNewHighScore) {
      saveHighScore(email, score, level, difficulty);
      setShowLeaderboard(true);
    }
  };

  const [showLauncher, setShowLauncher] = useState(true);

  const startLevel = (lvl: number) => {
    const config = LEVEL_CONFIG[lvl] || LEVEL_CONFIG[5];
    setTheme(config.theme);
    
    const { grid: newGrid, startPos } = generateMaze(config.w, config.h, config.shape, difficulty);
    
    setGrid(newGrid);
    setPlayerPos(startPos);
    setLevel(lvl);
    
    // Add 3 random unique items every level
    const starterItems = [ItemType.Health, ItemType.Weapon, ItemType.Antivenom, ItemType.IceCube, ItemType.CO2, ItemType.Water, ItemType.Rope, ItemType.Shield];
    const newItems: ItemTypeValues[] = [];
    while(newItems.length < 3) {
      const item = starterItems[Math.floor(Math.random() * starterItems.length)];
      if (!newItems.includes(item)) {
        newItems.push(item);
      }
    }
    setBag(prev => [...prev, ...newItems]);

    if (lvl === 1) {
      setHp(100);
      setScore(0);
      setScoreHistory([]);
      setMessageLog(['Welcome to the Nebula Maze!', 'You received 3 starter items. Good luck!']);
    } else {
      addLog(`Level ${lvl} started! +3 Items`);
    }
    
    updateVisibility(newGrid, startPos.x, startPos.y);
    playSound('levelUp');
    
    setScoreHistory(prev => [...prev, { level: lvl, score }]);
  };

  const updateVisibility = (currentGrid: Cell[][], px: number, py: number) => {
    const newGrid = [...currentGrid];
    const h = newGrid.length;
    const w = newGrid[0].length;

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        newGrid[y][x].visible = false;
        const dist = Math.sqrt(Math.pow(px - x, 2) + Math.pow(py - y, 2));
        if (dist <= VISIBILITY_RADIUS) {
          newGrid[y][x].seen = true;
          newGrid[y][x].visible = true;
        }
      }
    }
    setGrid(newGrid);
  };

  const addLog = (msg: string) => {
    setMessageLog(prev => [msg, ...prev].slice(0, 50));
  };

  // --- MOVEMENT ---
  const move = useCallback((dx: number, dy: number) => {
    if (modal.isOpen) return;

    const newX = playerPos.x + dx;
    const newY = playerPos.y + dy;

    if (newX < 0 || newX >= grid[0].length || newY < 0 || newY >= grid.length) {
      playSound('bump');
      return;
    }

    const currentCell = grid[playerPos.y][playerPos.x];
    const targetCell = grid[newY][newX];

    // Check Walls
    let blocked = false;
    if (dx === 1 && (currentCell.walls & Direction.E)) blocked = true;
    if (dx === -1 && (currentCell.walls & Direction.W)) blocked = true;
    if (dy === 1 && (currentCell.walls & Direction.S)) blocked = true;
    if (dy === -1 && (currentCell.walls & Direction.N)) blocked = true;

    if (blocked || !targetCell.valid) {
      playSound('bump');
      return;
    }

    // Move
    setPlayerPos({ x: newX, y: newY });
    updateVisibility(grid, newX, newY);
    playSound('step');

    // Academic Prompt Trigger (5% chance on empty cells)
    if (targetCell.item === ItemType.Empty && Math.random() < 0.05) {
      const question = registry.getRandom();
      if (question) {
        setModal({
          isOpen: true,
          type: 'question',
          title: 'Academic Challenge',
          message: 'Solve this to gain points!',
          question: question,
          onConfirm: (answer: string) => handleQuestionAnswer(answer, question)
        });
        playSound('hazard'); 
      }
    }

    // Check Item
    if (targetCell.item !== ItemType.Empty && targetCell.item !== ItemType.Start) {
      handleItem(targetCell.item, newX, newY);
    }
  }, [grid, playerPos, modal.isOpen]);

  const handleItem = (item: ItemTypeValues, x: number, y: number) => {
    const newGrid = [...grid];
    
    if (item === ItemType.Exit) {
      // Check if mostly explored (simple check: 80% of valid cells seen)
      const validCells = grid.flat().filter(c => c.valid);
      const seenCount = validCells.filter(c => c.seen).length;
      if (seenCount / validCells.length < 0.8) {
        addLog("The exit is locked! Explore more of the map.");
        playSound('bump');
        return;
      }
      
      // Level Complete
      setModal({
        isOpen: true,
        type: 'levelComplete',
        title: 'Level Complete!',
        message: `You found the exit! Score: ${score}`,
        onConfirm: () => {
          setModal({ ...modal, isOpen: false });
          checkAndStartLevel(level + 1, runCount, isPremium, adWatched);
        }
      });
      return;
    }

    // Hazards
    if ([ItemType.Hazard, ItemType.Fire, ItemType.Fumes, ItemType.Robber, ItemType.Snake, ItemType.Quicksand, ItemType.Bees, ItemType.Meteor, ItemType.Aliens, ItemType.Bear].includes(item)) {
      playSound('hazard');
      setEncounteredHazards(prev => Array.from(new Set([...prev, item])));
      setModal({
        isOpen: true,
        type: 'inventory',
        title: 'Hazard Encounter!',
        message: `You encountered: ${ITEMS_CONFIG[item].name}. Choose an item to use:`,
        hazardType: item,
        onConfirm: (selectedItem) => resolveHazard(item, selectedItem, x, y)
      });
      return;
    }

    // Pickups
    newGrid[y][x].item = ItemType.Empty;
    setGrid(newGrid);
    playSound('pickup');

    if (item === ItemType.Score) {
      setScore(s => s + 100);
      addLog("Found a Gem! +100 Score");
    } else if (item === ItemType.Health) {
      setHp(h => Math.min(100, h + 20));
      addLog("Used Health Pack. +20 HP");
    } else {
      setBag(prev => [...prev, item]);
      addLog(`Picked up ${ITEMS_CONFIG[item].name}`);
    }
  };

  const resolveHazard = (hazardType: string, usedItem: string | null, x: number, y: number) => {
    let success = false;
    let msg = '';
    let hpLoss = 0;
    let scoreLoss = 0;

    // Map hazardType to encounter ID
    let encounterId = '';
    if (hazardType === ItemType.Fire) encounterId = 'forest_fire';
    else if (hazardType === ItemType.Fumes) encounterId = 'toxic_fumes';
    else if (hazardType === ItemType.Robber) encounterId = 'robber';
    else if (hazardType === ItemType.Snake) encounterId = 'snake_bite';
    else if (hazardType === ItemType.Quicksand) encounterId = 'quicksand';
    else if (hazardType === ItemType.Bees) encounterId = 'bee_sting';
    else if (hazardType === ItemType.Meteor) encounterId = 'meteor_storm';
    else if (hazardType === ItemType.Aliens) encounterId = 'violent_alien';
    else if (hazardType === ItemType.Bear) encounterId = 'hostile_wildlife';
    else if (hazardType === ItemType.Hazard) {
       // Random other hazard
       const others = ['snake_bite', 'bee_sting', 'quicksand', 'hostile_wildlife', 'dog_bite', 'leopard_attack', 'gorilla_attack'];
       encounterId = others[Math.floor(Math.random() * others.length)];
    }

    const encounter = encounters.find(e => e.id === encounterId);
    
    if (encounter) {
      const remedies = encounter.remedies as Record<string, number>;
      const basePoints = encounter.base_points;
      
      if (usedItem && remedies[usedItem] !== undefined) {
        // Valid remedy
        const mitigation = remedies[usedItem];
        hpLoss = mitigation; // Usually negative or 0
        success = true;
        msg = `You used ${ITEMS_CONFIG[usedItem].name}. Effect: ${mitigation} HP`;
      } else {
        // Invalid or no item
        hpLoss = basePoints;
        success = false;
        msg = `Failed! ${encounter.name} hit you for ${basePoints} HP.`;
        if (usedItem && encounter.invalid_choice_rule === 'apply_full_loss_and_consume_item') {
           msg += ` You also lost your ${ITEMS_CONFIG[usedItem].name}.`;
        }
      }
    } else {
      // Fallback for unknown hazards
      if (usedItem === ItemType.Weapon || usedItem === ItemType.Antivenom) success = true;
      if (success) {
        msg = "You survived!";
      } else {
        hpLoss = -20;
        msg = "Ouch! -20 HP";
      }
    }

    // Apply Effects
    setHp(h => h + hpLoss);
    
    // Remove item from bag
    if (usedItem) setBag(prev => {
      const idx = prev.indexOf(usedItem as ItemTypeValues);
      if (idx > -1) {
        const newBag = [...prev];
        newBag.splice(idx, 1);
        return newBag;
      }
      return prev;
    });

    // Clear hazard
    const newGrid = [...grid];
    newGrid[y][x].item = ItemType.Empty;
    setGrid(newGrid);

    const FAILURE_PHRASES = [
      "Better luck next time",
      "Read More Often",
      "Ask a Teacher",
      "Don't give up!",
      "Keep trying!",
      "Knowledge is power"
    ];
    const failureTitle = FAILURE_PHRASES[Math.floor(Math.random() * FAILURE_PHRASES.length)];

    setModal({
      isOpen: true,
      type: 'alert',
      title: success ? 'Result' : failureTitle,
      message: msg,
      onConfirm: () => {
        setModal({ ...modal, isOpen: false });
        if (hp + hpLoss <= 0) gameOver();
      }
    });
  };

  const gameOver = () => {
    playSound('die');
    const isHigh = isHighScore(score);
    setIsNewHighScore(isHigh);
    
    setModal({
      isOpen: true,
      type: 'gameOver',
      title: 'Game Over',
      message: `You perished in the maze. Final Score: ${score}`,
      onConfirm: () => {
        if (isHigh) {
          if (!userEmail) {
            setShowSignup(true);
          } else {
            saveHighScore(userEmail, score, level, difficulty);
            setShowLeaderboard(true);
          }
        } else {
          setModal({ ...modal, isOpen: false });
          setShowLauncher(true);
        }
      }
    });
  };

  // --- KEYBOARD ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showLauncher) return;
      switch (e.key) {
        case 'ArrowUp': move(0, -1); break;
        case 'ArrowDown': move(0, 1); break;
        case 'ArrowLeft': move(-1, 0); break;
        case 'ArrowRight': move(1, 0); break;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [move, showLauncher]);

  // --- RENDER HELPERS ---
  const handleManualMove = (dx: number, dy: number) => {
    if (modal.isOpen) return;
    move(dx, dy);
  };

  const handleQuestionAnswer = (answer: string | null, question: Question) => {
    if (!answer) {
      // Skip (-5 points)
      setScore(s => Math.max(0, s - 5));
      addLog('Skipped question. -5 points.');
      setModal({ ...modal, isOpen: false });
      setTextAnswer('');
      return;
    }

    const isCorrect = checkAnswer(question, answer);
    if (isCorrect) {
      // Correct (+10 to +40 points)
      // Difficulty scaling: Easy=10, Hard=20, Tough=40
      const points = difficulty === 'easy' ? 10 : difficulty === 'hard' ? 20 : 40;
      setScore(s => s + points);
      addLog(`Correct! +${points} points.`);
      playSound('correct');
    } else {
      // Wrong (-10 points)
      setScore(s => Math.max(0, s - 10));
      addLog('Wrong answer. -10 points.');
      playSound('wrong');
    }
    setModal({ ...modal, isOpen: false });
    setTextAnswer('');
  };

  const renderEncounter = () => {
    if (modal.type === 'inventory') {
      const hazardItem = modal.hazardType as ItemTypeValues;
      const hazardConfig = ITEMS_CONFIG[hazardItem];

      return (
        <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 animate-in zoom-in">
          <div className="flex flex-col items-center mb-6">
            {hazardConfig && (
              <div className={`text-6xl mb-2 ${hazardConfig.color} animate-bounce`}>
                {hazardConfig.char}
              </div>
            )}
            <h2 className="text-2xl font-bold text-white text-center">{modal.title}</h2>
            {hazardConfig && (
              <div className="text-cyan-400 font-bold text-lg mt-1">{hazardConfig.name}</div>
            )}
          </div>
          
          <p className="text-slate-300 mb-6 text-center">{modal.message}</p>
          
          <div className="grid grid-cols-3 gap-3 mb-6">
            {bag.map((item, i) => (
              <button
                key={i}
                onClick={() => modal.onConfirm && modal.onConfirm(item)}
                className="aspect-square bg-slate-700 hover:bg-slate-600 rounded-lg flex flex-col items-center justify-center gap-1 transition-colors border border-slate-600"
                title={ITEMS_CONFIG[item]?.name}
              >
                <span className="text-2xl">{ITEMS_CONFIG[item]?.char}</span>
                <span className="text-[10px] text-slate-400 truncate w-full text-center px-1">{ITEMS_CONFIG[item]?.name}</span>
              </button>
            ))}
          </div>
          
          <button
            onClick={() => modal.onConfirm && modal.onConfirm(null)}
            className="w-full py-2 bg-red-900/50 hover:bg-red-900/80 text-red-200 rounded-lg text-sm font-bold transition-colors border border-red-900 mb-4"
          >
            Take Damage (No Item)
          </button>
        </div>
      );
    }
    
    if (modal.type === 'question' && modal.question) {
      const isTextType = !modal.question.options || modal.question.options.length === 0;

      return (
        <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 animate-in zoom-in max-w-md w-full">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-lg font-bold text-white">Academic Challenge</h2>
            <span className="text-xs bg-cyan-900 text-cyan-200 px-2 py-1 rounded uppercase">{modal.question.category}</span>
          </div>
          
          {modal.question.image && (
            <div className="mb-4 rounded-lg overflow-hidden border border-slate-600 bg-black flex justify-center">
              <img 
                src={modal.question.image} 
                alt="Question" 
                className="max-h-48 object-contain"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  console.error('Image failed to load:', modal.question?.image);
                }}
              />
            </div>
          )}
          
          <p className="text-slate-300 mb-6 font-medium text-lg">{modal.question.text}</p>
          
          <div className="space-y-3">
            {!isTextType ? (
              modal.question.options?.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => modal.onConfirm && modal.onConfirm(opt)}
                  className="w-full p-4 text-left bg-slate-700 hover:bg-slate-600 rounded-lg text-slate-200 transition-colors border border-slate-600 hover:border-cyan-500 font-medium"
                >
                  {opt}
                </button>
              ))
            ) : (
              <div className="space-y-3">
                <input
                  type="text"
                  value={textAnswer}
                  onChange={(e) => setTextAnswer(e.target.value)}
                  placeholder="Type your answer..."
                  className="w-full p-3 bg-slate-900 border border-slate-600 rounded-lg text-white focus:border-cyan-500 focus:outline-none"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      modal.onConfirm && modal.onConfirm(textAnswer);
                    }
                  }}
                />
                <button
                  onClick={() => modal.onConfirm && modal.onConfirm(textAnswer)}
                  className="w-full py-3 bg-cyan-700 hover:bg-cyan-600 text-white rounded-lg font-bold transition-colors"
                >
                  Submit Answer
                </button>
              </div>
            )}
            
            <button
              onClick={() => modal.onConfirm && modal.onConfirm(null)}
              className="w-full py-2 mt-4 text-slate-500 hover:text-slate-300 text-sm font-medium transition-colors"
            >
              Skip Question (-5 points)
            </button>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-slate-200 font-sans selection:bg-cyan-500/30">
      {/* HEADER */}
      <header className="h-16 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4 z-30 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-2 rounded-lg shadow-lg shadow-cyan-500/20">
            <MapIcon className="text-white w-6 h-6" />
          </div>
          <h1 className="font-black text-xl tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400 hidden sm:block">
            NEBULA <span className="text-cyan-400">MAZE</span>
          </h1>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-slate-800/50 px-3 py-1.5 rounded-full border border-slate-700">
            <Trophy className="w-4 h-4 text-yellow-500" />
            <span className="font-mono font-bold text-yellow-500">{score}</span>
          </div>
          <div className="flex items-center gap-2 bg-slate-800/50 px-3 py-1.5 rounded-full border border-slate-700">
            <div className={`w-2 h-2 rounded-full ${hp > 50 ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
            <span className="font-mono font-bold text-white">{hp}%</span>
          </div>
          <button onClick={() => setShowLeaderboard(true)} className="p-2 hover:bg-slate-800 rounded-full transition-colors">
            <Trophy className="w-5 h-5 text-slate-400" />
          </button>
          <button onClick={() => setShowOperator(true)} className="p-2 hover:bg-slate-800 rounded-full transition-colors">
            <Settings className="w-5 h-5 text-slate-400" />
          </button>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        {/* LAUNCHER OVERLAY */}
        {showLauncher && (
          <Launcher 
            onStart={handleLauncherStart} 
            difficulty={difficulty} 
            setDifficulty={setDifficulty}
            playerIcon={playerIcon}
            setPlayerIcon={setPlayerIcon}
          />
        )}

        {/* MAZE AREA */}
        <div className="flex-1 relative bg-slate-950 flex flex-col items-center justify-center p-4 gap-4" ref={containerRef}>
          <div 
            className="relative bg-slate-900 rounded-xl shadow-2xl overflow-hidden border border-slate-800"
            style={{
              width: Math.min(600, (containerRef.current?.clientWidth || 600) - 32),
              height: Math.min(600, (containerRef.current?.clientHeight || 600) - 160),
            }}
          >
            {/* Grid Rendering */}
            <div 
              className="absolute inset-0 grid"
              style={{
                gridTemplateColumns: `repeat(${grid[0]?.length || 1}, 1fr)`,
                gridTemplateRows: `repeat(${grid.length || 1}, 1fr)`,
              }}
            >
              {grid.map((row, y) => row.map((cell, x) => {
                const isPlayer = playerPos.x === x && playerPos.y === y;
                const isVisible = cell.visible;
                const isSeen = cell.seen;
                
                if (!cell.valid) return <div key={`${x}-${y}`} className="bg-slate-950" />;
                
                return (
                  <div 
                    key={`${x}-${y}`} 
                    className={`
                      relative transition-all duration-300
                      ${isVisible ? THEME_COLORS[theme] : isSeen ? 'bg-slate-900' : 'bg-black'}
                    `}
                  >
                    {/* Walls */}
                    {(isVisible || isSeen) && (
                      <>
                        {(cell.walls & Direction.N) ? <div className={`absolute top-0 left-0 right-0 h-[2px] border-t-2 ${isVisible ? 'border-slate-600' : 'border-slate-600/30'}`} /> : null}
                        {(cell.walls & Direction.S) ? <div className={`absolute bottom-0 left-0 right-0 h-[2px] border-b-2 ${isVisible ? 'border-slate-600' : 'border-slate-600/30'}`} /> : null}
                        {(cell.walls & Direction.W) ? <div className={`absolute top-0 bottom-0 left-0 w-[2px] border-l-2 ${isVisible ? 'border-slate-600' : 'border-slate-600/30'}`} /> : null}
                        {(cell.walls & Direction.E) ? <div className={`absolute top-0 bottom-0 right-0 w-[2px] border-r-2 ${isVisible ? 'border-slate-600' : 'border-slate-600/30'}`} /> : null}
                      </>
                    )}

                    {/* Items */}
                    {isVisible && cell.item !== ItemType.Empty && ITEMS_CONFIG[cell.item] && (
                      <div className={`absolute inset-0 flex items-center justify-center text-lg ${ITEMS_CONFIG[cell.item].color}`}>
                        {ITEMS_CONFIG[cell.item].char}
                      </div>
                    )}

                    {/* Player */}
                    {isPlayer && (
                      <div className="absolute inset-0 flex items-center justify-center z-10">
                        <PlayerAvatar type={playerIcon} className="w-[80%] h-[80%] drop-shadow-lg animate-bounce-player" />
                      </div>
                    )}
                    
                    {/* Fog Overlay (Seen but not visible) */}
                    {isSeen && !isVisible && (
                      <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-[1px]" />
                    )}

                    {/* Walls - Explored (Rendered ON TOP of fog for visibility) */}
                    {isSeen && !isVisible && (
                      <>
                        {(cell.walls & Direction.N) ? <div className="absolute top-0 left-0 right-0 h-[2px] border-t-2 border-slate-500/30" /> : null}
                        {(cell.walls & Direction.S) ? <div className="absolute bottom-0 left-0 right-0 h-[2px] border-b-2 border-slate-500/30" /> : null}
                        {(cell.walls & Direction.W) ? <div className="absolute top-0 bottom-0 left-0 w-[2px] border-l-2 border-slate-500/30" /> : null}
                        {(cell.walls & Direction.E) ? <div className="absolute top-0 bottom-0 right-0 w-[2px] border-r-2 border-slate-500/30" /> : null}
                      </>
                    )}
                  </div>
                );
              }))}
            </div>
          </div>

          {/* On-Screen Controls */}
          <div className="grid grid-cols-3 gap-2">
            <div />
            <button 
              onClick={() => handleManualMove(0, -1)} 
              className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-lg hover:bg-slate-700 active:bg-slate-600 flex items-center justify-center text-2xl shadow-lg transition-all active:scale-95"
              aria-label="Move Up"
            >
              ⬆️
            </button>
            <div />
            <button 
              onClick={() => handleManualMove(-1, 0)} 
              className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-lg hover:bg-slate-700 active:bg-slate-600 flex items-center justify-center text-2xl shadow-lg transition-all active:scale-95"
              aria-label="Move Left"
            >
              ⬅️
            </button>
            <button 
              onClick={() => handleManualMove(0, 1)} 
              className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-lg hover:bg-slate-700 active:bg-slate-600 flex items-center justify-center text-2xl shadow-lg transition-all active:scale-95"
              aria-label="Move Down"
            >
              ⬇️
            </button>
            <button 
              onClick={() => handleManualMove(1, 0)} 
              className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-lg hover:bg-slate-700 active:bg-slate-600 flex items-center justify-center text-2xl shadow-lg transition-all active:scale-95"
              aria-label="Move Right"
            >
              ➡️
            </button>
          </div>
        </div>

        {/* SIDEBAR / DASHBOARD */}
        <div className="w-full md:w-80 h-[40%] md:h-auto min-h-[300px] md:min-h-0 bg-slate-900 border-t md:border-t-0 md:border-l border-slate-800 flex flex-col z-20 shadow-2xl md:shadow-none">
          <div className="p-4 border-b border-slate-800">
            <h2 className="font-bold text-white flex items-center gap-2">
              <Backpack className="w-4 h-4 text-cyan-400" />
              Explorer's Dashboard
            </h2>
          </div>

          <div className="flex-1 overflow-hidden relative p-4">
            {modal.isOpen && (modal.type === 'question' || modal.type === 'inventory') ? (
              renderEncounter()
            ) : (
              <div className="h-full flex flex-col gap-4 animate-in fade-in">
                {/* Score & Stats */}
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700 flex justify-between items-center">
                  <div>
                    <div className="text-xs text-slate-500 uppercase tracking-wider font-bold">Score</div>
                    <div className="text-2xl font-mono font-bold text-yellow-500">{score}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-500 uppercase tracking-wider font-bold">Health</div>
                    <div className={`text-2xl font-mono font-bold ${hp > 50 ? 'text-green-500' : 'text-red-500'}`}>{hp}%</div>
                  </div>
                </div>

                {/* Inventory */}
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                  <h3 className="text-sm font-semibold text-slate-400 mb-3 flex items-center gap-2">
                    <Shield className="w-4 h-4" /> Inventory
                  </h3>
                  <div className="grid grid-cols-4 gap-2">
                    {bag.length === 0 && <span className="text-xs text-slate-500 col-span-4 italic">Empty bag...</span>}
                    {bag.map((item, i) => (
                      <div key={i} className="aspect-square bg-slate-700 rounded flex items-center justify-center text-xl border border-slate-600" title={ITEMS_CONFIG[item]?.name}>
                        {ITEMS_CONFIG[item]?.char}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Hazards Encountered */}
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                  <h3 className="text-sm font-semibold text-slate-400 mb-3 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" /> Hazards Encountered
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {encounteredHazards.length === 0 && <span className="text-xs text-slate-500 italic">None yet...</span>}
                    {encounteredHazards.map((hazard, i) => (
                      <div key={i} className="w-8 h-8 bg-slate-700 rounded flex items-center justify-center text-lg border border-slate-600" title={ITEMS_CONFIG[hazard]?.name}>
                        {ITEMS_CONFIG[hazard]?.char}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Log */}
                <div className="flex-1 bg-black/40 rounded-lg p-3 overflow-hidden flex flex-col border border-slate-800">
                  <h3 className="text-xs font-semibold text-slate-500 mb-2 uppercase tracking-wider">Mission Log</h3>
                  <div className="flex-1 overflow-y-auto space-y-1 font-mono text-sm">
                    {messageLog.map((msg, i) => (
                      <div key={i} className={`truncate ${i === 0 ? 'text-white' : 'text-slate-500'}`}>
                        <span className="opacity-50 mr-2">{'>'}</span>{msg}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* MODALS */}
        {showLeaderboard && <Leaderboard scores={getHighScores()} onClose={() => setShowLeaderboard(false)} />}
        {showOperator && <OperatorPanel onClose={() => setShowOperator(false)} />}
        {showSignup && <SignupPrompt onSignup={handleSignup} onSkip={() => { setShowSignup(false); }} />}
        {showPaywall && <Paywall onUnlock={handlePaywallUnlock} onClose={() => { setShowPaywall(false); setShowLauncher(true); }} />}
        
        {/* Mobile Modal Container */}
        {modal.isOpen && modal.type !== 'inventory' && modal.type !== 'question' && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-sm shadow-2xl p-6 animate-in zoom-in">
              <h2 className="text-xl font-bold text-white mb-2">{modal.title}</h2>
              <p className="text-slate-300 mb-6">{modal.message}</p>
              <button 
                onClick={() => modal.onConfirm && modal.onConfirm()}
                className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-bold transition"
              >
                Continue
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
