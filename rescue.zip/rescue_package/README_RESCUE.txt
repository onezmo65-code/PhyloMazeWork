NEBULA MAZE - RESCUE PACKAGE
============================

This package contains the current version of Nebula Maze (v1.4.0).

CONTENTS
--------
1. build/  - The production-ready game.
2. source/ - The full source code.

HOW TO PLAY (QUICK)
-------------------
1. Open the "build" folder.
2. Open "index.html" in your web browser.
   Note: Some browsers may block local file loading due to CORS policies.
   If it doesn't load, you need a local server.

   Easiest way to run a local server (if you have Python):
   - Open terminal/cmd in the "build" folder.
   - Run: python3 -m http.server
   - Go to http://localhost:8000

HOW TO DEVELOP / BUILD FROM SOURCE
----------------------------------
1. Install Node.js (https://nodejs.org/).
2. Open terminal in the "source" folder.
3. Run: npm install
4. Run: npm run dev  (to play locally)
5. Run: npm run build (to create a new build)

DEPLOYMENT
----------
To put this game on the internet:
1. Upload the contents of the "build" folder to any static host.
   - GitHub Pages
   - Netlify
   - Vercel
   - Neocities
   - Amazon S3

MOBILE
------
To run on mobile, you can use the web version in a mobile browser.
For a native app experience, you can wrap the "build" folder using Capacitor or Cordova.
