import { MazeGame } from "./components/MazeGame";

function App() {
  return (
    <MazeGame />
  );
}

export default App;