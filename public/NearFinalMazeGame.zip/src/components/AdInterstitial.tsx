import React, { useState, useEffect } from 'react';
import { X, Play } from 'lucide-react';

interface AdInterstitialProps {
  onClose: () => void;
}

export const AdInterstitial: React.FC<AdInterstitialProps> = ({ onClose }) => {
  const [timeLeft, setTimeLeft] = useState(5);
  const [canClose, setCanClose] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanClose(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col items-center justify-center p-4">
      <div className="absolute top-4 right-4">
        {canClose ? (
          <button 
            onClick={onClose}
            className="bg-white/20 hover:bg-white/30 text-white p-2 rounded-full backdrop-blur-sm transition-colors"
          >
            <X className="w-8 h-8" />
          </button>
        ) : (
          <div className="text-white font-mono bg-black/50 px-3 py-1 rounded-full">
            Reward in {timeLeft}s
          </div>
        )}
      </div>

      <div className="max-w-lg w-full bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-slate-800">
        <div className="aspect-video bg-slate-800 flex items-center justify-center relative group cursor-pointer">
          {/* Mock Video Ad */}
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 to-purple-900 opacity-50" />
          <Play className="w-16 h-16 text-white opacity-80 group-hover:scale-110 transition-transform z-10" />
          <div className="absolute bottom-4 left-4 text-white z-10">
            <div className="font-bold text-lg">Nebula Watch</div>
            <div className="text-sm text-slate-300">Time is relative. Style is eternal.</div>
          </div>
        </div>
        <div className="p-6">
          <h3 className="text-xl font-bold text-white mb-2">Sponsored Content</h3>
          <p className="text-slate-400 text-sm">
            Thanks for playing Nebula Maze! Watching this short ad supports the developer and keeps the first few levels free.
          </p>
          <button className="mt-4 w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-bold transition-colors">
            Learn More
          </button>
        </div>
      </div>
    </div>
  );
};
