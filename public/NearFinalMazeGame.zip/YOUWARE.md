# YOUWARE.md

# Nebula Maze: Fog of War (v1.7.1)

A React-based dungeon crawler game with fog of war mechanics, inventory system, and AI-generated content.

## Project Overview

- **Project Type**: React + TypeScript Game
- **Entry Point**: `src/main.tsx` -> `src/App.tsx` -> `src/components/MazeGame.tsx`
- **Build System**: Vite
- **Styling**: Tailwind CSS
- **Version**: 1.7.1

## Key Features

- **Procedural Generation**: Randomly generated mazes with varying difficulty levels and shapes.
- **Fog of War**: Visibility system that reveals the map as the player explores.
- **Inventory System**: Expanded inventory with 30+ items.
- **Hazard System**: Data-driven encounters with interactive mitigation.
- **Academic Encounters**: Trivia questions with scoring.
- **Monetization**:
  - **Free Trial**: First 2 runs are free.
  - **Ad Interstitial**: Mandatory ad (or currency notes fallback) after 2nd run.
  - **Paywall**: 3rd run triggers a paywall.
    - Weekly Pass ($0.99)
    - Monthly Pass ($2.99)
    - Yearly Pro ($15.99)
- **Leaderboard**: Local storage persistence for high scores.
- **Audio System**: Synthesized sound effects and background music (MusicPlayer).

## Architecture

### Components

- **MazeGame.tsx**: Main game container. Manages layout, game loop, state, rendering, and audio.
- **Launcher**: Landing page component (internal to MazeGame).
- **AdInterstitial.tsx**: Video ad interstitial component.
- **Paywall.tsx**: Monetization overlay.
- **PlayerAvatar.tsx**: SVG component for the player character.
- **OperatorPanel.tsx**: Admin interface for managing questions and game settings (audio volume).
- **Leaderboard.tsx**: High score display.
- **MusicPlayer.tsx**: Handles background music playback with volume control.

### Utils

- **mazeUtils.ts**: Maze generation, logic, and theme configuration.
- **questionUtils.ts**: Question loading and validation registry.
- **leaderboardUtils.ts**: Score persistence.

### State Management

- **GameState**: Managed in `MazeGame.tsx` (grid, player, score, bag, level, difficulty, theme).
- **User State**: `localStorage` tracks `runCount`, `isPremium`, `userEmail`, and `highscores`.

## Styling

- **Tailwind CSS**: Used for all styling.
- **Custom Animations**: Defined in `tailwind.config.js` (e.g., `bounce-player`, `flash-alert`).

## Development

### Commands

- **Install**: `npm install`
- **Dev**: `npm run dev`
- **Build**: `npm run build`
- **Preview**: `npm run preview`
- **Lint**: `npm run lint`

### Environment Variables

- `VITE_API_KEY`: Google Gemini API Key (optional for AI features).
