package com.onesmo.nebulamaze;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
