import { useState } from "react";
import { MazeGame } from "./components/MazeGame";
import { signInWithGoogle, testAdminUpload } from "./services/storageTest";

function App() {
  const [status, setStatus] = useState<string>("");

  const handleSignIn = async () => {
    try {
      setStatus("Signing in...");
      const user = await signInWithGoogle();
      setStatus(`Signed in as: ${user?.email} (${user?.uid})`);
    } catch (err: any) {
      setStatus(`Sign-in Error: ${err.message}`);
    }
  };

  const handleUpload = async () => {
    try {
      setStatus("Uploading...");
      await testAdminUpload();
      setStatus("✅ Upload successful! Check Storage > Files > public/admin-test.txt");
    } catch (err: any) {
      setStatus(`❌ Upload failed: ${err.message}`);
    }
  };

  return (
    <>
      <div className="p-4 bg-gray-800 text-white mb-4">
        <h2 className="text-xl font-bold mb-2">Admin Test Panel</h2>
        <div className="flex gap-2 mb-2">
          <button 
            onClick={handleSignIn}
            className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
          >
            1. Sign In (Google)
          </button>
          <button 
            onClick={handleUpload}
            className="px-4 py-2 bg-green-600 rounded hover:bg-green-700"
          >
            2. Test Upload
          </button>
        </div>
        <pre className="bg-black p-2 rounded text-sm overflow-auto max-h-20">
          {status || "Ready..."}
        </pre>
      </div>
      <MazeGame />
    </>
  );
}

export default App;