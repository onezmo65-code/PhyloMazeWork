# Nebula Maze Build Fixes

This package contains the fixed configuration files to resolve:
1. "Project with path ... could not be found" (Missing Firebase plugins)
2. "Unsupported class file major version 65" (Java 21 incompatibility)
3. Admin Upload Test UI

## Instructions

1. Extract this zip file into your project root folder.
   It will overwrite:
   - android/settings.gradle
   - android/build.gradle
   - src/App.tsx
   - src/services/storageTest.ts

2. Open a terminal (PowerShell) and navigate to the `android` folder:
   cd "C:\NewApp\Gemini3MazeRescue\Source code\Nebula Maze App\android"

3. Run the build:
   .\gradlew assembleDebug

## Note on Java Versions
There is no "multifunction java" installer. You MUST use Java 17 for this project.
Ensure your JAVA_HOME is set to Java 17 before running the build.
